package mx.edu.utez.aweb.pokeapp.service.ability;

public class ServiceAbility {
}
